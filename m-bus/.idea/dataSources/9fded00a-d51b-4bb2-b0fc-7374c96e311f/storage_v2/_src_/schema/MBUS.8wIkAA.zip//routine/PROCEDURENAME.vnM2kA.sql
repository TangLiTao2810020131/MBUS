create procedure procedureName
as
       totalCount number(10);
begin
       select count(*) into totalCount from TB_ROOM;
       DBMS_OUTPUT.put_line('班级名：'|| totalCount);
end;
/

